const { 
    Events, 
    EmbedBuilder, 
    ActionRowBuilder, 
    ButtonBuilder, 
    ButtonStyle,
    StringSelectMenuBuilder,
    StringSelectMenuOptionBuilder 
} = require('discord.js');
const fs = require('fs');
const path = require('path');
// const { addMatchResult } = require('../utils/rankUtils'); // << NOVO IMPORT DO RANKING

// --- Configurações/Caminhos ---
const emojis = require('../DataBaseJson/emojis.json');
const filaPath = path.join(__dirname, '../DataBaseJson/mediadores.json');
const cargosPath = path.join(__dirname, '../DataBaseJson/mediador.json'); 
const configPath = path.join(__dirname, '../config.json'); 
const permsPath = path.join(__dirname, '../DataBaseJson/perms.json'); 


// --- Funções Auxiliares (Reutilizadas para Consistência) ---

// Função para ler a fila, garantindo que seja um array
function readFila() {
    if (fs.existsSync(filaPath)) {
        try {
            const raw = fs.readFileSync(filaPath);
            const data = JSON.parse(raw);
            return Array.isArray(data) ? data : []; 
        } catch (e) {
            console.error("Erro ao ler mediadores.json:", e);
            return [];
        }
    }
    return [];
}

// Função para salvar a fila
function saveFila(filaArray) {
    fs.writeFileSync(filaPath, JSON.stringify(filaArray, null, 2));
}

// Função para verificar se o usuário é Owner ou tem permissão
function isOwnerOrPermitted(userId) {
    try {
        const config = JSON.parse(fs.readFileSync(configPath));
        if (config.ownerId === userId) return true;
        
        if (fs.existsSync(permsPath)) {
            const perms = JSON.parse(fs.readFileSync(permsPath));
            return Object.keys(perms).includes(userId);
        }
        return false;
    } catch (e) {
        return false;
    }
}

// Função para construir a ActionRow completa de botões (agora reutilizável)
function buildModeratorButtons() {
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId('entrar_fila')
            .setLabel('Entrar na fila')
            .setStyle(ButtonStyle.Success)
            .setEmoji(emojis.member_add_emoji || '➕'),
        new ButtonBuilder()
            .setCustomId('sair_fila')
            .setLabel('Sair da fila')
            .setStyle(ButtonStyle.Danger)
            .setEmoji(emojis.member_remove_emoji || '➖'),
        new ButtonBuilder()
            .setCustomId('selecionar_mediador_para_remocao')
            .setLabel('Remover Mediador')
            .setStyle(ButtonStyle.Primary)
            .setEmoji('🧹')
    );
}


module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction) {
        
        // 🛑 Handler de Menus de Seleção (Dropdown) 🛑
        if (interaction.isStringSelectMenu()) {
            
            // Lógica de Remoção de Mediador (EXISTENTE)
            if (interaction.customId === 'remover_mediador_dropdown') {
                
                if (!isOwnerOrPermitted(interaction.user.id)) {
                    return interaction.reply({ content: '❌ Apenas o dono do bot pode usar este menu!', ephemeral: true });
                }

                await interaction.deferReply({ ephemeral: true });

                const selectedUserId = interaction.values[0];
                let fila = readFila();
                
                const initialLength = fila.length;
                fila = fila.filter(id => id !== selectedUserId);
                
                if (fila.length < initialLength) {
                    saveFila(fila); 

                    let desc = fila.length > 0 ? fila.map(u => `<@${u}> \`${u}\``).join('\n') : 'Nenhum mediador na fila.';
                    const newEmbed = new EmbedBuilder()
                        .setTitle(`${emojis.information_emoji || 'ℹ️'} Fila de Mediadores`)
                        .setDescription('Entre ou saia da fila de mediadores usando os botões abaixo.')
                        .addFields({ name: 'Admins Especiais Atuais:', value: desc }) 
                        .setColor(0x2ecc71);

                    const row = buildModeratorButtons(); 
                    await interaction.message.edit({ embeds: [newEmbed], components: [row] }).catch(() => {});

                    await interaction.editReply({
                        content: `✅ **Sucesso!** O mediador <@${selectedUserId}> foi removido da fila. O painel principal foi atualizado.`
                    });
                } else {
                    await interaction.editReply({
                        content: `❌ Erro: O mediador <@${selectedUserId}> não foi encontrado na fila.`
                    });
                }
                return;
            }
            
            // --- NOVO BLOCO: ATRIBUIÇÃO DE RANK (VITÓRIA) ---
            if (interaction.customId === 'atribuir_vitoria') {
                
                // 1. Verificação de Permissão de Mediador
                // ⚠️ SUBSTITUA 'ID_DO_SEU_CARGO_DE_MEDIADOR' pelo ID real do cargo.
                const cargosPermitidos = JSON.parse(fs.readFileSync(cargosPath));
                const isMediator = interaction.member.roles.cache.some(role => cargosPermitidos.includes(role.id)) || isOwnerOrPermitted(interaction.user.id);
                
                if (!isMediator) {
                    return interaction.reply({ content: '❌ Apenas mediadores podem atribuir a vitória.', ephemeral: true });
                }

                await interaction.deferReply({ ephemeral: true });

                const winnerId = interaction.values[0]; // ID do usuário selecionado como VENCEDOR

                // 2. RECUPERAÇÃO DO PERDEDOR (CRÍTICO!)
                // ⚠️ Você DEVE adaptar esta lógica para recuperar os IDs dos dois jogadores da partida.
                // Substitua os placeholders abaixo pela sua lógica de busca dos jogadores A e B.
                
                // Exemplo Fictício para fins de demonstração:
                const ID_JOGADOR_A = 'ID_A_RECUPERADO_DA_PARTIDA'; 
                const ID_JOGADOR_B = 'ID_B_RECUPERADO_DA_PARTIDA'; 
                
                let loserId;
                
                if (winnerId === ID_JOGADOR_A) {
                    loserId = ID_JOGADOR_B;
                } else if (winnerId === ID_JOGADOR_B) {
                    loserId = ID_JOGADOR_A;
                } else {
                     return interaction.editReply({ 
                         content: '❌ Erro: O vencedor selecionado não é um dos jogadores desta partida.', 
                         ephemeral: true 
                     });
                }

                // 3. ATRIBUIÇÃO DOS PONTOS
                addMatchResult(winnerId, loserId);

                // 4. Resposta e Opcional: Remoção da mensagem da partida
                await interaction.editReply({ 
                    content: `✅ Partida finalizada! Vencedor: <@${winnerId}> (+1 Vitória). Perdedor: <@${loserId}> (+1 Derrota).` 
                });

                // Opcional: Deletar a mensagem da partida após atribuir pontos
                // interaction.message.delete().catch(() => {}); 
                
                return;
            }
        }
        
        // 🛑 Handler de Botões 🛑
        if (interaction.isButton()) {
            const customId = interaction.customId;

            // Lógica para Abrir o Menu de Seleção (Remoção)
            if (customId === 'selecionar_mediador_para_remocao') {
                
                if (!isOwnerOrPermitted(interaction.user.id)) {
                    return interaction.reply({ content: '❌ Apenas o dono do bot pode usar este botão!', ephemeral: true });
                }

                const fila = readFila();

                if (fila.length === 0) {
                    return interaction.reply({ content: 'ℹ️ A fila de mediadores já está vazia!', ephemeral: true });
                }

                const cargosPermitidos = JSON.parse(fs.readFileSync(cargosPath));

                // Filtrar apenas mediadores que ainda possuem o cargo
                const options = await Promise.all(fila.map(async userId => {
                    const member = await interaction.guild.members.fetch(userId).catch(() => null);
                    
                    const displayName = member ? member.displayName : `Usuário Desconhecido (${userId})`;
                    
                    return new StringSelectMenuOptionBuilder()
                        .setLabel(displayName)
                        .setValue(userId);
                }));

                const selectMenu = new StringSelectMenuBuilder()
                    .setCustomId('remover_mediador_dropdown')
                    .setPlaceholder('Selecione o mediador para remover...')
                    .addOptions(options);

                const row = new ActionRowBuilder().addComponents(selectMenu);

                return interaction.reply({
                    content: 'Selecione um mediador abaixo para removê-lo da fila:',
                    components: [row],
                    ephemeral: true
                });
            }
            
            // Handler dos botões de Entrar/Sair da fila 
            if (customId === 'entrar_fila' || customId === 'sair_fila') {
                
                await interaction.deferReply({ ephemeral: true });

                let fila = readFila(); 
                let cargosPermitidos = [];
                if (fs.existsSync(cargosPath)) {
                    cargosPermitidos = JSON.parse(fs.readFileSync(cargosPath));
                }
                const userId = interaction.user.id;
                let mudou = false;
                let replyContent = '';
                
                if (customId === 'entrar_fila') {
                    const member = await interaction.guild.members.fetch(userId);
                    const temCargo = member.roles.cache.some(role => cargosPermitidos.includes(role.id));

                    if (!temCargo) {
                        replyContent = `${emojis.failuser_emoji || '❌'} Você precisa do cargo de mediador para entrar na fila!`;
                    } else if (fila.includes(userId)) {
                        replyContent = `${emojis.failuser_emoji || '❌'} Você já está na fila de mediadores!`;
                    } else {
                        fila.push(userId);
                        mudou = true;
                        replyContent = `${emojis.successuser_emoji || '✅'} Você entrou na fila de mediadores!`;
                    }
                } 
                
                else if (customId === 'sair_fila') {
                    if (!fila.includes(userId)) {
                        replyContent = `${emojis.failuser_emoji || '❌'} Você não está na fila de mediadores!`;
                    } else {
                        fila = fila.filter(id => id !== userId);
                        mudou = true;
                        replyContent = `${emojis.successuser_emoji || '✅'} Você saiu da fila de mediadores!`;
                    }
                }

                if (mudou) {
                    saveFila(fila); 
                }
                
                // ATUALIZAÇÃO DA MENSAGEM PRINCIPAL
                let desc = fila.length > 0 ? fila.map(u => `<@${u}> \`${u}\``).join('\n') : 'Nenhum mediador na fila.';
                
                const embed = new EmbedBuilder()
                    .setTitle(`${emojis.information_emoji || 'ℹ️'} Fila de Mediadores`)
                    .setDescription('Entre ou saia da fila de mediadores usando os botões abaixo.')
                    .addFields({ name: 'Admins Especiais Atuais:', value: desc })
                    .setColor(0x2ecc71);
                
                const row = buildModeratorButtons();

                await interaction.message.edit({ embeds: [embed], components: [row] }).catch(() => {});
                
                await interaction.editReply({ content: replyContent });
                return;
            }
        }

        // 🛑 Handler de comandos de Slash 🛑
        if (!interaction.isChatInputCommand()) return;
        
        const command = interaction.client.commands.get(interaction.commandName);
        if (!command) {
            console.error(`Nenhum comando correspondente a ${interaction.commandName} foi encontrado.`);
            return;
        }
        try {
            await command.execute(interaction);
        } catch (error) {
            console.error(error);
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp({ content: 'Houve um erro ao executar este comando!', ephemeral: true });
            } else {
                await interaction.reply({ content: 'Houve um erro ao executar este comando!', ephemeral: true });
            }
        }
    },
};