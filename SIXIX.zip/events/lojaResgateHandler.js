const { Events, EmbedBuilder, ChannelType, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');
const path = require('path');

// --- Caminhos ---
const usersPath = path.join(__dirname, '../DataBaseJson/usersinfo.json');
const lojaPath = path.join(__dirname, '../DataBaseJson/loja.json');
const emojis = require('../DataBaseJson/emojis.json');

// --- Funções Auxiliares de Dados ---

// Gerencia Pontos do Usuário (Corrigida para resolver ReferenceError)
function getUserInfo(id) {
    let db = {};
    if (fs.existsSync(usersPath)) db = JSON.parse(fs.readFileSync(usersPath, 'utf8'));
    if (!db[id]) db[id] = { id, vitorias: 0, derrotas: 0, pontos: 0, partidas: 0 };
    return db[id];
}

function saveUserInfo(user) {
    let db = {};
    if (fs.existsSync(usersPath)) db = JSON.parse(fs.readFileSync(usersPath, 'utf8'));
    db[user.id] = user;
    fs.writeFileSync(usersPath, JSON.stringify(db, null, 2));
}

// Leitura da Configuração da Loja (Suporta todos os novos campos)
function readLoja() {
    if (fs.existsSync(lojaPath)) {
        try {
            const data = JSON.parse(fs.readFileSync(lojaPath, 'utf8'));
            if (!data.items) data.items = [];
            if (!data.logChannelId) data.logChannelId = null;
            if (!data.categoryChannelId) data.categoryChannelId = null; 
            if (!data.adminRoleId) data.adminRoleId = null; // Inclui Cargo Admin
            return data;
        } catch (e) {
            // Retorna a estrutura limpa em caso de erro JSON
            return { items: [], logChannelId: null, categoryChannelId: null, adminRoleId: null };
        }
    }
    return { items: [], logChannelId: null, categoryChannelId: null, adminRoleId: null };
}
// -----------------------

module.exports = {
    // 🔑 Correção para resolver "ReferenceError: Events is not defined"
    name: Events.InteractionCreate, 
    
    async execute(interaction) {
        if (!interaction.isButton() || !interaction.customId.startsWith('loja_resgatar_')) return;

        await interaction.deferReply({ ephemeral: true });

        const itemId = interaction.customId.replace('loja_resgatar_', '');
        const lojaData = readLoja();
        const item = lojaData.items.find(i => i.id === itemId);
        
        // 🆕 Lendo todas as configurações do JSON
        const logChannelId = lojaData.logChannelId;
        const categoryChannelId = lojaData.categoryChannelId;
        const ADMIN_ROLE_ID = lojaData.adminRoleId; // ID do cargo configurado via /configloja

        if (!item) {
            return interaction.editReply({ content: '❌ Item não encontrado na loja. O painel pode estar desatualizado.' });
        }

        let userStats = getUserInfo(interaction.user.id);

        if (userStats.pontos < item.preco) {
            return interaction.editReply({
                content: `❌ Você não tem pontos suficientes para resgatar **${item.nome}**.\n` +
                         `Seus pontos atuais: **${userStats.pontos}** / Preço: **${item.preco}**`
            });
        }

        // --- Processamento da Compra ---
        userStats.pontos -= item.preco;
        saveUserInfo(userStats);

        let newChannel;
        let channelMention = "Nenhum canal de resgate criado."; 
        
        // --- Lógica de Criação de Canal de Resgate (Se a categoria estiver configurada) ---
        if (categoryChannelId) {
            try {
                const safeUsername = interaction.user.username.toLowerCase().replace(/[^a-z0-z0-9]/g, '').substring(0, 15);
                const channelName = `resgate-${safeUsername}-${item.id.substring(0, 4)}`;
                
                const permissionOverwrites = [
                    // Permite que o bot veja
                    { id: interaction.client.user.id, allow: [PermissionFlagsBits.ViewChannel] },
                    // Permite que o usuário que resgatou veja
                    { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages] },
                    // Impede @everyone de ver
                    { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
                ];

                // Adiciona permissão para o cargo ADMIN, SE ele estiver configurado
                if (ADMIN_ROLE_ID) {
                    permissionOverwrites.push({ 
                        id: ADMIN_ROLE_ID, 
                        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels] 
                    });
                }
                
                newChannel = await interaction.guild.channels.create({
                    name: channelName,
                    type: ChannelType.GuildText,
                    parent: categoryChannelId,
                    topic: `Resgate do item: ${item.nome} | Usuário: ${interaction.user.tag}`,
                    permissionOverwrites: permissionOverwrites,
                });
                
                channelMention = newChannel.toString();
                
                // Mensagem inicial no novo canal
                newChannel.send({
                    content: `<@${interaction.user.id}>, ${ADMIN_ROLE_ID ? `<@&${ADMIN_ROLE_ID}>` : 'Admin'}!\n\n**Novo resgate detectado:**\nItem: **${item.nome}**\nPreço: **${item.preco} pontos**\n\nUm administrador irá atendê-lo em breve.`,
                }).catch(e => console.error("Erro ao enviar mensagem inicial do canal:", e));

            } catch (e) {
                console.error("Erro ao criar canal de resgate:", e);
                channelMention = `❌ Erro ao criar canal! Verifique se a Categoria (${categoryChannelId}) existe e se o bot tem a permissão **Gerenciar Canais** nela.`;
            }
        }

        // --- Log no Canal de Logs ---
        if (logChannelId) {
            const logChannel = interaction.guild.channels.cache.get(logChannelId);
            
            if (logChannel) {
                const logEmbed = new EmbedBuilder()
                    .setTitle(`${emojis.confirmed_emoji || '✅'} RESGATE DE ITEM!`)
                    .setDescription(`O usuário ${interaction.user} resgatou um item da loja.`)
                    .addFields(
                        { name: 'Item Resgatado:', value: `${item.nome} (ID: \`${item.id}\`)`, inline: true },
                        { name: 'Pontos Deduzidos:', value: `${item.preco}`, inline: true },
                        { name: 'Canal de Atendimento:', value: channelMention, inline: false }
                    )
                    .setColor(0x2ecc71)
                    .setTimestamp();
                    
                await logChannel.send({ embeds: [logEmbed] }).catch(e => console.error("Erro ao enviar log:", e));
            }
        }

        // --- Resposta ao Usuário ---
        return interaction.editReply({
            content: `✅ Você resgatou **${item.nome}** com sucesso!\n` +
                     `**${item.preco} pontos** foram deduzidos. Seus pontos restantes: **${userStats.pontos}**.\n\n` +
                     `**Seu canal de atendimento:** ${channelMention}`
        });
    }
};