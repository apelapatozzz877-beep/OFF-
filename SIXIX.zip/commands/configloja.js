const { SlashCommandBuilder, EmbedBuilder, ChannelType } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid'); 

// --- Caminhos ---
const lojaPath = path.join(__dirname, '../DataBaseJson/loja.json');
const configPath = path.join(__dirname, '../config.json'); 
const permsPath = path.join(__dirname, '../DataBaseJson/perms.json'); 
const emojis = require('../DataBaseJson/emojis.json');

// --- Funções de Loja (Atualizada para suportar o novo campo adminRoleId) ---
function readLoja() {
    if (fs.existsSync(lojaPath)) {
        try {
            const data = JSON.parse(fs.readFileSync(lojaPath, 'utf8'));
            if (!data.items) data.items = [];
            if (!data.logChannelId) data.logChannelId = null;
            if (!data.categoryChannelId) data.categoryChannelId = null; 
            if (!data.adminRoleId) data.adminRoleId = null; // 🆕 Inicializa novo campo
            return data;
        } catch (e) {
            console.error("Erro ao ler loja.json:", e);
            return { items: [], logChannelId: null, categoryChannelId: null, adminRoleId: null };
        }
    }
    return { items: [], logChannelId: null, categoryChannelId: null, adminRoleId: null };
}

function saveLoja(data) {
    fs.writeFileSync(lojaPath, JSON.stringify(data, null, 2));
}

// 🔑 FUNÇÃO DE PERMISSÃO (Deve estar definida aqui, como corrigimos antes)
function isOwnerOrPermitted(userId) {
    try {
        const config = JSON.parse(fs.readFileSync(configPath));
        if (config.ownerId === userId) return true;
        
        if (fs.existsSync(permsPath)) {
            const perms = JSON.parse(fs.readFileSync(permsPath));
            return Object.keys(perms).includes(userId);
        }
        return false;
    } catch {
        return false;
    }
}
// -----------------------

module.exports = {
    data: new SlashCommandBuilder()
        .setName('configloja')
        .setDescription('Configura os itens e as opções da loja de pontos (Admin/Owner).')
        // ... (Subcomandos: adicionar, remover, listar, setlogchannel, setcategory)
        .addSubcommand(subcommand =>
            subcommand
                .setName('adicionar')
                .setDescription('Adiciona um novo produto à loja.')
                .addStringOption(option => option.setName('nome').setDescription('Nome do produto (Ex: Cargo VIP Temporário)').setRequired(true))
                .addIntegerOption(option => option.setName('preco').setDescription('Preço do produto em pontos de ranking').setRequired(true))
                .addStringOption(option => option.setName('descricao').setDescription('Descrição breve do produto').setRequired(false))
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('remover')
                .setDescription('Remove um produto da loja pelo seu ID.')
                .addStringOption(option => option.setName('id').setDescription('ID único do produto a ser removido (Use /configloja listar)').setRequired(true))
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('listar')
                .setDescription('Lista todos os produtos configurados na loja.')
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('setlogchannel')
                .setDescription('Define o canal onde serão enviados os logs de resgate de itens.')
                .addChannelOption(option => 
                    option.setName('canal')
                        .setDescription('O canal de texto para logs de resgate.')
                        .setRequired(true)
                )
        )
        .addSubcommand(subcommand =>
            subcommand
                .setName('setcategory')
                .setDescription('Define a categoria para criar canais de resgate de prêmios.')
                .addChannelOption(option => 
                    option.setName('categoria')
                        .setDescription('A categoria onde os canais de resgate serão criados.')
                        .addChannelTypes(ChannelType.GuildCategory) 
                        .setRequired(true)
                )
        )
        // 🆕 NOVO SUBCOMANDO PARA CARGO ADMIN
        .addSubcommand(subcommand =>
            subcommand
                .setName('setadminrole')
                .setDescription('Define o cargo que será notificado e terá acesso aos canais de resgate.')
                .addRoleOption(option => 
                    option.setName('cargo')
                        .setDescription('O cargo de Staff/Admin responsável pela entrega de prêmios.')
                        .setRequired(true)
                )
        ),

    async execute(interaction) {
        if (!isOwnerOrPermitted(interaction.user.id)) {
            return interaction.reply({ content: '❌ Apenas administradores podem configurar a loja.', ephemeral: true });
        }

        const lojaData = readLoja();
        const subcommand = interaction.options.getSubcommand();

        await interaction.deferReply({ ephemeral: true });

        // --- LÓGICA DO SUBCOMANDO SETADMINROLE ---
        if (subcommand === 'setadminrole') {
            const role = interaction.options.getRole('cargo');
            
            lojaData.adminRoleId = role.id;
            saveLoja(lojaData);

            return interaction.editReply({
                content: `✅ O cargo de administração da loja foi definido para **${role.name}**!`,
            });
        }
        
        // --- LÓGICA DO SUBCOMANDO SETCATEGORY ---
        else if (subcommand === 'setcategory') {
            const category = interaction.options.getChannel('categoria');
            
            if (category.type !== ChannelType.GuildCategory) {
                 return interaction.editReply({ content: '❌ Por favor, selecione uma **Categoria** válida.' });
            }

            lojaData.categoryChannelId = category.id;
            saveLoja(lojaData);

            return interaction.editReply({
                content: `✅ A categoria para criação de canais de resgate foi definida para **${category.name}**!`,
            });
        }

        // --- LÓGICA DO SUBCOMANDO SETLOGCHANNEL ---
        else if (subcommand === 'setlogchannel') {
            const channel = interaction.options.getChannel('canal');
            
            if (channel.type !== ChannelType.GuildText) {
                 return interaction.editReply({ content: '❌ Por favor, selecione um **canal de texto** válido.' });
            }

            lojaData.logChannelId = channel.id;
            saveLoja(lojaData);

            return interaction.editReply({
                content: `✅ O canal de logs da loja foi definido para ${channel}.`,
            });
        }
        
        // --- LÓGICA DO SUBCOMANDO ADICIONAR ---
        else if (subcommand === 'adicionar') {
            const nome = interaction.options.getString('nome');
            const preco = interaction.options.getInteger('preco');
            const descricao = interaction.options.getString('descricao') || 'Sem descrição.';
            const id = uuidv4().substring(0, 8); 

            if (preco <= 0) {
                return interaction.editReply({ content: '❌ O preço deve ser maior que zero.' });
            }

            const novoItem = { id, nome, preco, descricao };
            lojaData.items.push(novoItem);
            saveLoja(lojaData);

            return interaction.editReply({
                content: `✅ Produto **${nome}** (ID: \`${id}\`) adicionado com sucesso por **${preco} pontos**.`
            });
        } 
        
        // --- LÓGICA DO SUBCOMANDO REMOVER ---
        else if (subcommand === 'remover') {
            const id = interaction.options.getString('id');
            const initialLength = lojaData.items.length;
            
            lojaData.items = lojaData.items.filter(item => item.id !== id);

            if (lojaData.items.length < initialLength) {
                saveLoja(lojaData);
                return interaction.editReply({
                    content: `✅ Produto com ID \`${id}\` removido com sucesso.`
                });
            } else {
                return interaction.editReply({
                    content: `❌ Produto com ID \`${id}\` não encontrado.`
                });
            }
        } 
        
        // --- LÓGICA DO SUBCOMANDO LISTAR (Atualizado para mostrar o Cargo Admin) ---
        else if (subcommand === 'listar') {
            if (lojaData.items.length === 0) {
                return interaction.editReply({ content: 'ℹ️ A loja não possui produtos configurados.' });
            }

            const description = lojaData.items.map(item =>
                `**${item.nome}** (ID: \`${item.id}\`)\n` +
                `Preço: **${item.preco} pontos**\n` +
                `Descrição: *${item.descricao}*`
            ).join('\n\n---\n\n');

            const logStatus = lojaData.logChannelId ? `<#${lojaData.logChannelId}>` : 'Não configurado.';
            const categoryStatus = lojaData.categoryChannelId ? `<#${lojaData.categoryChannelId}>` : 'Não configurada.';
            const adminRoleStatus = lojaData.adminRoleId ? `<@&${lojaData.adminRoleId}>` : 'Não configurado.'; // 🆕 Adicionado

            const embed = new EmbedBuilder()
                .setTitle(`${emojis.information_emoji || '🛒'} Produtos Configuradas da Loja`)
                .setDescription(description.substring(0, 4000))
                .addFields(
                    { name: 'Canal de Logs Atual:', value: logStatus, inline: false },
                    { name: 'Categoria de Resgate:', value: categoryStatus, inline: false },
                    { name: 'Cargo de Administração:', value: adminRoleStatus, inline: false } // 🆕 Adicionado
                )
                .setColor(0xf1c40f);

            return interaction.editReply({ embeds: [embed] });
        }
    }
};