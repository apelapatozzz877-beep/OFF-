const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const fs = require('fs');
const path = require('path');

// --- Caminhos ---
const lojaPath = path.join(__dirname, '../DataBaseJson/loja.json');
const configPath = path.join(__dirname, '../config.json'); 
const permsPath = path.join(__dirname, '../DataBaseJson/perms.json'); 
const emojis = require('../DataBaseJson/emojis.json');

// --- Funções Auxiliares (Reutilizadas) ---
function readLoja() {
    if (fs.existsSync(lojaPath)) {
        try {
            return JSON.parse(fs.readFileSync(lojaPath, 'utf8'));
        } catch (e) {
            return { items: [] };
        }
    }
    return { items: [] };
}

function isOwnerOrPermitted(userId) {
    try {
        const config = JSON.parse(fs.readFileSync(configPath));
        if (config.ownerId === userId) return true;
        if (fs.existsSync(permsPath)) {
            const perms = JSON.parse(fs.readFileSync(permsPath));
            return Object.keys(perms).includes(userId);
        }
        return false;
    } catch {
        return false;
    }
}
// -----------------------

module.exports = {
    data: new SlashCommandBuilder()
        .setName('setloja')
        .setDescription('Envia o painel da loja de pontos para o canal.'),

    async execute(interaction) {
        if (!isOwnerOrPermitted(interaction.user.id)) {
            return interaction.reply({ content: '❌ Apenas administradores podem enviar o painel da loja.', ephemeral: true });
        }

        await interaction.deferReply({ ephemeral: true });

        const lojaData = readLoja();
        const items = lojaData.items;

        if (items.length === 0) {
            return interaction.editReply({ content: '❌ A loja não possui produtos configurados. Use `/configloja adicionar` primeiro.' });
        }
        
        // Constrói a descrição da Loja
        const description = items.map((item, index) =>
            `${index + 1}. **${item.nome}**\n` +
            `   Preço: **${item.preco} pontos**\n` +
            `   *${item.descricao}*`
        ).join('\n\n');

        const embed = new EmbedBuilder()
            .setTitle(`${emojis.information_emoji || '🛒'} Loja de Resgate de Pontos`)
            .setDescription(description.substring(0, 4000))
            .setColor(0x3498db)
            .setFooter({ text: 'Use os botões abaixo para resgatar os itens.' });

        // Constrói os botões (limitado a 5 botões por linha, usaremos uma linha)
        const row = new ActionRowBuilder();
        items.slice(0, 5).forEach((item, index) => { // Limita a 5 itens por simplicidade
            row.addComponents(
                new ButtonBuilder()
                    .setCustomId(`loja_resgatar_${item.id}`)
                    .setLabel(`Resgatar ${index + 1}`)
                    .setStyle(ButtonStyle.Primary)
                    .setEmoji(emojis._star_emoji || '⭐')
            );
        });

        await interaction.channel.send({ embeds: [embed], components: [row] });
        return interaction.editReply({ content: '✅ Painel da loja enviado com sucesso!' });
    }
};