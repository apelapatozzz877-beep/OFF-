const { EventEmitter } = require('events');

EventEmitter.defaultMaxListeners = 30;

module.exports = {
  
}; 